Fully working PHP/AJAX contact form is available in the pro version of the template.
You can buy it from: https://templatemag.com/dashio-bootstrap-admin-template/
